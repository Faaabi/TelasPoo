package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Professor;
import com.leandersonandre.agenda.core.service.ProfessorServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProfessorController {

    @Autowired
    ProfessorServico professorServico;

    @GetMapping("/prof_add")
    public String prof_add() {
        return "prof/prof_add.html";
    }

    @GetMapping("/prof_edit")
    public String prof_edit() {
        return "prof/prof_edit.html";
    }

    @GetMapping("/prof")
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("prof/index_prof.html");
        view.addObject("profs", professorServico.obterTodos());
        return view;
    }
    @GetMapping("/prof/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("prof/prof_edit.html");
        var opt = professorServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }
    @GetMapping("prof/criar")
    public ModelAndView criarNovoProfessor(){
        ModelAndView view = new ModelAndView("prof/prof_add.html");
        view.addObject("entidade", new Professor());
        return view;
    }
    @PostMapping("prof/criar")
    public ModelAndView criar(@ModelAttribute("entidade")Professor professor) {
        try {
            System.out.println(professor);
            professor.setId(0);
            professorServico.salvar(professor);
            return new ModelAndView("redirect:/prof");
        } catch (Exception e) {
            e.printStackTrace();
            ModelAndView model = new ModelAndView("prof/prof_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", professor);
            return model;
        }
    }
    @PostMapping("profs/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade")Professor professor){
        try {
            professorServico.salvar(professor);
            return new ModelAndView("redirect:/prof");
        }catch (Exception e){
            ModelAndView model = new ModelAndView("prof/prof_edit.html");
            model.addObject("erro",e.getMessage());
            model.addObject("entidade", professor);
            return model;
        }
    }
}
