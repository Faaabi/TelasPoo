package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.*;
import com.leandersonandre.agenda.core.service.*;
import com.leandersonandre.agenda.dto.CursoMateriaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/materia")
public class MateriaController {
    @Autowired
    MateriaServico materiaServico;
    TurmaServico turmaServico;
    @Autowired
    CursoServico cursoServico;
    ProfessorServico professorServico;
    SalaServico salaServico;


    @GetMapping
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("materia/index_materia.html");
        List<Curso> lista = cursoServico.obterTodos();
        List<CursoMateriaDTO> dto = new ArrayList<>();
        for(var c:lista){
            CursoMateriaDTO cursoMateriaDTO = new CursoMateriaDTO();
            cursoMateriaDTO.setCurso(c);
            cursoMateriaDTO.setLista(materiaServico.obterTodosCurso(c));
            dto.add(cursoMateriaDTO);
        }
        view.addObject("curso", dto);
        return view;
    }

        @GetMapping("/materia_add")
        public String materia_add(){
            return "materia/materia_add.html";
        }

        @GetMapping("/materia_edit")
        public String materia_edit(){
            return "materia/materia_edit.html";
        }

        @GetMapping("/criar")
        public ModelAndView criarNovoMateria(){
            ModelAndView view = new ModelAndView("materia/materia_add.html");
            List<Curso> curso = cursoServico.obterTodos();
            view.addObject("curso", curso);
            List<Turma> turma = materiaServico.obterTodosTurma();
            view.addObject("turma", turma);
            List<Professor> professor = materiaServico.obterTodosProfessor();
            view.addObject("professor", professor);
            List<Sala> sala = materiaServico.obterTodosSala();
            view.addObject("sala", sala);
            view.addObject("entidade", new Materia());
            return view;
    }
    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade")Materia materia) {
        try {
            materiaServico.salvar(materia);
            return new ModelAndView("redirect:/materia");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("materia/materia_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", materia);
            return model;
        }
    }
    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("materia/materia_edit.html");
        var opt = materiaServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        List<Materia> materia = materiaServico.obterTodos();
        view.addObject("materia", materia);
        return view;
    }
    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Materia materia){
        try {
            materiaServico.salvar(materia);
            return new ModelAndView("redirect:/materia");
        }catch (Exception e){
            ModelAndView model = new ModelAndView("materia/materia_edit.html");
            model.addObject("erro",e.getMessage());
            model.addObject("entidade", materia);
            return model;
        }
    }
}

