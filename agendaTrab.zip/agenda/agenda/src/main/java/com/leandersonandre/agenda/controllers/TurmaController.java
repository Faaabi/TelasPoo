package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Curso;
import com.leandersonandre.agenda.core.entity.Turma;
import com.leandersonandre.agenda.core.service.CursoServico;
import com.leandersonandre.agenda.core.service.TurmaServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/turma")
public class TurmaController {

    @Autowired
    TurmaServico turmaServico;
    @Autowired
    CursoServico cursoServico;

    @GetMapping
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("turma/index_turma.html");
        view.addObject("turmas", turmaServico.obterTodos());
        return view;
    }
    @GetMapping("/turma_add")
    public String prof_add(){
        return "prof/prof_add.html";
    }

    @GetMapping("/turma_edit")
    public String turma_edit(){
        return "turma/turma_edit.html";
    }

    @GetMapping("/criar")
    public ModelAndView criarNovoTurma(){
        ModelAndView view = new ModelAndView("turma/turma_add.html");
        List<Curso> curso = turmaServico.obterTodosCurso();
        view.addObject("curso", curso);
        view.addObject("entidade", new Turma()); // Supondo que Turma seja a entidade
        return view;
    }
    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade")Turma turma) {
        try {
            turmaServico.salvar(turma);
            return new ModelAndView("redirect:/turma");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("turma/turma_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", turma);
            return model;
        }

    }
    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("turma/turma_edit.html");
        var opt = turmaServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        List<Curso> curso = turmaServico.obterTodosCurso();
        view.addObject("curso", curso);
        return view;
    }
    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Turma turma){
        try {
            turmaServico.salvar(turma);
            return new ModelAndView("redirect:/turma");
        }catch (Exception e){
            ModelAndView model = new ModelAndView("turma/turma_edit.html");
            model.addObject("erro",e.getMessage());
            model.addObject("entidade", turma);
            return model;
        }
    }

}
