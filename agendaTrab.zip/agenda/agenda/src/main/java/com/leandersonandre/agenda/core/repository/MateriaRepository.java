package com.leandersonandre.agenda.core.repository;

import com.leandersonandre.agenda.core.entity.Curso;
import com.leandersonandre.agenda.core.entity.Materia;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MateriaRepository extends JpaRepository<Materia, Long> {
    List<Materia>findAllByCurso(Curso curso);
}
