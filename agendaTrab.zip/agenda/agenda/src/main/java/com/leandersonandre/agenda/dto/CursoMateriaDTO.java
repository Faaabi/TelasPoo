package com.leandersonandre.agenda.dto;

import com.leandersonandre.agenda.core.entity.Curso;
import com.leandersonandre.agenda.core.entity.Materia;

import java.util.List;

public class CursoMateriaDTO {
    private Curso curso;

    private List<Materia> lista;

    public Curso getCurso() {
        return curso;
    }

    public List<Materia> getLista() {
        return lista;
    }

    public void setLista(List<Materia> lista) {
        this.lista = lista;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    }



