package com.leandersonandre.agenda.core.service;


import com.leandersonandre.agenda.core.entity.Horario;
import com.leandersonandre.agenda.core.repository.HorarioRepository;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class HorarioServico {

    @Autowired
    private HorarioRepository horarioRepository;


    public List<Horario> obterTodos() {
        return horarioRepository.findAll();
    }

    public Optional<Horario> obterPeloId(long id) {

        return horarioRepository.findById(id);
    }
    public void salvar(Horario horario) {
        if(Strings.isBlank(horario.getHorafim())){
            throw new RuntimeException("Favor informar a Horario do Fim");
        }
        if(Strings.isBlank(horario.getHorainicio())){
            throw new RuntimeException("Favor informar a Horario do Inicio");
        }

        horarioRepository.save(horario);

    }
}
