package com.leandersonandre.agenda.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping
    public String inicio(){
        return "inicio/index.html";
    }
    @GetMapping("/inicio")
    public String inicioset(){

        return "inicio/index.html";
    }
}
