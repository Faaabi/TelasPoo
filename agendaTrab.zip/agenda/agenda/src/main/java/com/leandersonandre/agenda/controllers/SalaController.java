package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Sala;
import com.leandersonandre.agenda.core.service.SalaServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SalaController {

    @Autowired
    SalaServico salaServico;
    @GetMapping("/sala_add")
    public String sala_add(){
        return "sala/sala_add.html";
    }

    @GetMapping("/sala_edit")
    public String sala_edit(){
        return "sala/sala_edit.html";
    }

    @GetMapping("/sala")
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("sala/index_sala.html");
        view.addObject("salas", salaServico.obterTodos());
        return view;
    }
    @GetMapping("sala/criar")
    public ModelAndView criarNovoSala(){
        ModelAndView view = new ModelAndView("sala/sala_add.html");
        view.addObject("entidade", new Sala());
        return view;

    }
    @PostMapping("sala/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Sala sala) {
        try {
            System.out.println(sala);
            sala.setId(0);
            salaServico.salvar(sala);
            return new ModelAndView("redirect:/sala");
        } catch (Exception e) {
            e.printStackTrace();
            ModelAndView model = new ModelAndView("sala/sala_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", sala);
            return model;
        }
    }
    @GetMapping("/sala/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("sala/sala_edit.html");
        var opt = salaServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }
    @PostMapping("salas/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Sala sala){
        try {
            salaServico.salvar(sala);
            return new ModelAndView("redirect:/sala");
        }catch (Exception e){
            ModelAndView model = new ModelAndView("sala/sala_edit.html");
            model.addObject("erro",e.getMessage());
            model.addObject("entidade", sala);
            return model;
        }
    }
}

