package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Horario;
import com.leandersonandre.agenda.core.service.HorarioServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class HorarioController {

    @Autowired
    HorarioServico horarioServico;

    @GetMapping("/horario")
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("horarios/index_horario.html");
        view.addObject("horario", horarioServico.obterTodos());
        return view;
    }
    @GetMapping("/hora_add")
    public String hora_add(){
        return "horarios/horario_add.html";
    }

    @GetMapping("/hora_edit")
    public String hora_edit(){
        return "horarios/horario_edit.html";
    }
    @GetMapping("/horarios/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("horarios/horario_edit.html");
        var opt = horarioServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }
    @GetMapping("horarios/criar")
    public ModelAndView criar(){
        ModelAndView view = new ModelAndView("horarios/horario_add.html");
        view.addObject("entidade", new Horario());
        return view;
    }
    @PostMapping("horarios/criar")
    public ModelAndView criar(@ModelAttribute("entidade")Horario horario) {
        try {
            System.out.println(horario);
            horario.setId(0);
            horarioServico.salvar(horario);
            return new ModelAndView("redirect:/horario");
        } catch (Exception e) {
            e.printStackTrace();
            ModelAndView model = new ModelAndView("horarios/horario_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", horario);
            return model;
        }
    }
    @PostMapping("horarios/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade")Horario horario){
        try {
            horarioServico.salvar(horario);
            return new ModelAndView("redirect:/horario");
        }catch (Exception e){
            ModelAndView model = new ModelAndView("horarios/horario_edit.html");
            model.addObject("erro",e.getMessage());
            model.addObject("entidade", horario);
            return model;
        }
    }

    }

