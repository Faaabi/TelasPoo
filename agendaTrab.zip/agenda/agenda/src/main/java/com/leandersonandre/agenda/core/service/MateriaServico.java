package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.*;
import com.leandersonandre.agenda.core.repository.*;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MateriaServico {
    @Autowired
    private MateriaRepository materiaRepository;
    @Autowired
    private CursoRepository cursoRepository;
    @Autowired
    private ProfessorRepository professorRepository;
    @Autowired
    private SalaRepository salaRepository;
    @Autowired
    private TurmaRepository turmaRepository;

    public List<Materia> obterTodos() {
        return materiaRepository.findAll();
    }

    public Optional<Materia> obterPeloId(long id) {

        return materiaRepository.findById(id);
    }
    public void salvar(Materia materia) {
        if(Strings.isBlank(materia.getNome())){
            throw new RuntimeException("Favor informar a Materia");
        }
        if(materia.getCurso()== null){
            throw new RuntimeException("Favor Selecione Materia");
        }
        if(materia.getProfessor()== null){
            throw new RuntimeException("Favor Selecione Professor");
        }
        if(materia.getSala()== null){
            throw new RuntimeException("Favor Selecione Sala");
        }
        if(materia.getTurma()== null){
            throw new RuntimeException("Favor Selecione Turma");
        }


        materiaRepository.save(materia);
    }
    public List<Materia> obterTodosCurso(Curso c){
        return materiaRepository.findAllByCurso(c);
    }
    public List<Professor> obterTodosProfessor(){
        return professorRepository.findAll();
    }
    public List<Turma> obterTodosTurma(){
        return turmaRepository.findAll();
    }
    public List<Sala> obterTodosSala(){
        return salaRepository.findAll();
    }

}


