package com.leandersonandre.agenda.controllers;


import com.leandersonandre.agenda.core.entity.Curso;
import com.leandersonandre.agenda.core.service.CursoServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CursoController {


    @Autowired
    CursoServico cursoServico;
    @GetMapping("/curso")
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("curso/index_curso.html");
        view.addObject("cursos", cursoServico.obterTodos());
        return view;
    }
    @GetMapping("/curso_add")
    public String curso_add(){
        return "curso/curso_add.html";
    }

    @GetMapping("/curso_edit")
    public String curso_edit(){
        return "curso/curso_edit.html";
    }
    @GetMapping("curso/criar")
    public ModelAndView criarNovoCurso(){
        ModelAndView view = new ModelAndView("curso/curso_add.html");
        view.addObject("entidade", new Curso());
        return view;
    }
    @PostMapping("curso/criar")
    public ModelAndView criar(@ModelAttribute("entidade")Curso curso) {
        try {
            System.out.println(curso);
            curso.setId(0);
            cursoServico.salvar(curso);
            return new ModelAndView("redirect:/curso");
        } catch (Exception e) {
            e.printStackTrace();
            ModelAndView model = new ModelAndView("curso/curso_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", curso);
            return model;
        }
    }
    @GetMapping("/curso/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("curso/curso_edit.html");
        var opt = cursoServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }
    @PostMapping("cursos/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Curso curso){
        try {
            cursoServico.salvar(curso);
            return new ModelAndView("redirect:/curso");
        }catch (Exception e){
            ModelAndView model = new ModelAndView("curso/curso_edit.html");
            model.addObject("erro",e.getMessage());
            model.addObject("entidade", curso);
            return model;
        }
    }
}


