insert into professor(nome) values ('Maria Silva');
insert into professor(nome) values ('João Pereira');
insert into professor(nome) values ('Ana Costa');
insert into professor(nome) values ('Carlos Oliveira');

insert into sala(nome) values ('101');
insert into sala(nome) values ('201');
insert into sala(nome) values ('301');

insert into curso(nome) values ('Engenharia de Computação');
insert into curso(nome) values ('Sistemas da Informação');
insert into curso(nome) values ('Engenharia Civil');

insert into turma(nome, curso_id) values ('144-1AN', 1);
insert into turma(nome, curso_id) values ('144-1BN', 2);
insert into turma(nome, curso_id) values ('130-1BN', 2);
insert into turma(nome, curso_id) values ('120-1AN', 3);

insert into materia(nome, turma_id, sala_id, professor_id, curso_id) values ('Programação Objetos', 1, 3, 2, 1);
insert into materia(nome, turma_id, sala_id, professor_id, curso_id) values ('Requisitos de Software', 1, 2, 1, 1);
insert into materia(nome, turma_id, sala_id, professor_id, curso_id) values ('Ética e Legislação', 2, 1, 1, 1);
insert into materia(nome, turma_id, sala_id, professor_id, curso_id) values ('Sistemas Operacionais', 3, 3, 2, 2);
insert into materia(nome, turma_id, sala_id, professor_id, curso_id) values ('Algoritimo de Programação', 1, 2, 3, 2);
insert into materia(nome, turma_id, sala_id, professor_id, curso_id) values ('Engenharia Civil', 2, 2, 1, 3);

INSERT INTO Horario(horainicio, horafim, dia)
VALUES ('08:00:00', '09:30:00', 'Segunda-feira');

INSERT INTO Horario(HoraInicio, HoraFim, Dia)
VALUES ('10:00:00', '11:30:00', 'Quarta-feira');

INSERT INTO Horario(HoraInicio, HoraFim, Dia)
VALUES ('13:00:00', '14:30:00', 'Sexta-feira');

INSERT INTO Horario(HoraInicio, HoraFim, Dia)
VALUES ('09:00:00', '10:30:00', 'Terça-feira');

INSERT INTO Horario(HoraInicio, HoraFim, Dia)
VALUES ('11:00:00', '12:30:00', 'Quinta-feira');

INSERT INTO Horario(HoraInicio, HoraFim, Dia)
VALUES ('14:00:00', '15:30:00', 'Quarta-feira');